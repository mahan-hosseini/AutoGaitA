# PackageGaitA
GaitA as a package
